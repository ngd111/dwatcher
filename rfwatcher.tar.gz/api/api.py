from flask import Flask, abort, jsonify, make_response
from flask_restful import Resource, Api
import sqlite3

app = Flask(__name__)
api = Api(app)


#conn = sqlite3.connect("../src/recording.db")


class ReadFilePath(Resource):
    def get(self, calluuid):
        print ('calluuid : %s' % calluuid)
        query = 'select filepath from recording where calluuid = ?'
        rv = self._query_db(query, calluuid)
        return {calluuid: rv}

    #def _query_db(query, args=(), one=True):
    def _query_db(self, query, _calluuid):
        try:
            conn = sqlite3.connect("../src/recording.db")
            #cur = conn.execute(query, (args))
            cur = conn.execute(query, (_calluuid, ))
            rv = cur.fetchall()
            cur.close()
            conn.close()
        except Exception, e:
            conn.close()

        if len(rv) == 0:
            abort(404)

        return rv[0]
        #return (rv[0] if rv else None) if one else rv

    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Origin','*')
        return response

    @app.errorhandler(404)
    def not_found(error):
        return make_response(jsonify({'error':'Not found'}), 404)

@app.route('/')
def base_route_point():
    return "Welcome to the Recording file search service"

api.add_resource(ReadFilePath, '/recording/<string:calluuid>')

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8000, debug=True, threaded=True)
