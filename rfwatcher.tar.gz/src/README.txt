# config file option
# log.loglevel : "standard" Or "debug"
# 	- standard : From warning to debug. Except info level logging
#   - debug    : Logging all level log script.

